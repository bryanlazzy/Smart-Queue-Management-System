<?php
// =====================================
// File 2: mark_sms_sent.php
// Place this in your capstone folder (same folder as config.php)
// =====================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow ESP32 to access

require 'config.php';

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['queuenumber'])) {
        $id = intval($_POST['queuenumber']);
        
        // Need to determine which table this ID belongs to
        $tables = ['assessment_window', 'posting_unholding_account', 'other_service'];
        $updated = false;
        
        foreach ($tables as $table) {
            // Check if ID exists in this table
            $checkSql = "SELECT queuenumber FROM `$table` WHERE queuenumber = ?";
            $checkStmt = $conn->prepare($checkSql);
            $checkStmt->bind_param("i", $id);
            $checkStmt->execute();
            $result = $checkStmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update this table
                $updateSql = "UPDATE `$table` SET sms_sent = 1, sms_sent_time = NOW() WHERE queuenumber = ?";
                $updateStmt = $conn->prepare($updateSql);
                $updateStmt->bind_param("i", $id);
                
                if ($updateStmt->execute()) {
                    echo json_encode([
                        "success" => true, 
                        "message" => "Marked as sent in $table",
                        "id" => $id,
                        "table" => $table
                    ]);
                    $updated = true;
                    $updateStmt->close();
                    break;
                }
                $updateStmt->close();
            }
            $checkStmt->close();
        }
        
        if (!$updated) {
            echo json_encode([
                "success" => false, 
                "message" => "ID not found in any table",
                "id" => $id
            ]);
        }
        
    } else {
        echo json_encode([
            "success" => false,
            "error" => "Invalid request - ID parameter missing"
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}

$conn->close();
?>
