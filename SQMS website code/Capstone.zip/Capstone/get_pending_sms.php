<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow ESP32 to access

require 'config.php';

try {
    $pending = array();
    
    // Query all three tables for pending SMS
    $tables = [
        'assessment_window' => 'Assessment & Finance Window',
        'posting_unholding_account' => 'Posting and Unholding of Account',
        'other_service' => 'Others'
    ];
    
    foreach ($tables as $table => $serviceName) {
        // Get entries where sms_sent is NULL or 0
        $sql = "SELECT 
                    queuenumber, 
                    name, 
                    contactnumber, 
                    '$serviceName' as service
                FROM `$table` 
                WHERE (sms_sent IS NULL OR sms_sent = 0)
                ORDER BY queuenumber ASC 
                LIMIT 5";
        
        $result = $conn->query($sql);
        
        if ($result && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $pending[] = $row;
            }
        }
    }
    
    echo json_encode([
        "success" => true,
        "pending" => $pending,
        "count" => count($pending),
        "timestamp" => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage(),
        "pending" => []
    ]);
}

$conn->close();
?>


<?php
