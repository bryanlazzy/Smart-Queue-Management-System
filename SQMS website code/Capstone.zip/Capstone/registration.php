<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Queue Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="styles/style.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #00743F;
            --light-green: #67C589;
            --accent-green: #B8E6C4;
            --bg-light: #F8FAF9;
            --text-dark: #2C3E50;
            --shadow-light: rgba(0, 116, 63, 0.1);
            --shadow-medium: rgba(0, 116, 63, 0.2);
            --dark-green-gradient: linear-gradient(135deg, var(--primary-green) 0%, #005a32 100%);
        }
    </style>
</head>
<body class="bg-light">

<div id="loader-overlay">
  <div class="loader-spinner"></div>
  <div class="loader-text">Loading Smart Queue Management System...</div>
</div>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand fs-5 fw-bold text-wrap" href="index.php">
            <i class="fas fa-project-diagram me-2"></i>Smart Queue Management System
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navItems"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navItems">
            <ul class="navbar-nav ms-auto">
                <?php if (basename($_SERVER['PHP_SELF']) === 'registration.php'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_login.php">
                            <i class="fas fa-user-shield me-1"></i> Admin Login
                        </a>
                    </li>
                <?php elseif (basename($_SERVER['PHP_SELF']) === 'admin_login.php'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="registration.php">
                            <i class="fas fa-arrow-left me-1"></i> Back to User Form
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5 pt-5"> <div class="card shadow-lg border-0"> <div class="card-header text-white text-center py-4"> <h2 class="mb-0">Register to Queue</h2>
            <p class="lead mb-0">Fill out the form below to get your queue number.</p>
        </div>
        <div class="card-body p-4"> <h3 class="card-title mb-4 text-center">SQMS Form</h3>
            <form action="submit.php" method="POST" class="needs-validation" novalidate> <div class="mb-3">
                    <label for="name" class="form-label fw-semibold">Full Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="name" name="name" required pattern="[A-Za-z ]{2,}" placeholder="e.g., Juan Dela Cruz">
                    <div class="invalid-feedback">
                        Please enter a valid full name (at least 2 letters, no numbers or special characters).
                    </div>
                </div>
                <div class="mb-3">
                    <label for="contactnumber" class="form-label fw-semibold">Mobile Number <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="contactnumber" name="contactnumber" required pattern="\d{10,15}" placeholder="e.g., 09123456789">
                    <div class="invalid-feedback">
                        Please enter a valid 10-15 digit mobile number.
                    </div>
                </div>
                <div class="mb-4"> <label for="service" class="form-label fw-semibold">Service Type <span class="text-danger">*</span></label>
                    <select name="service" class="form-select" id="service" required>
                        <option value="">-- Select Service --</option>
                        <option value="Assessment & Finance Window">Assessment & Finance Window</option>
                        <option value="Posting and Unholding of Account">Posting and Unholding of Account</option>
                        <option value="Others">Others</option>
                    </select>
                    <div class="invalid-feedback">
                        Please select a service type.
                    </div>
                </div>
                <div class="d-grid gap-2"> <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-paper-plane me-2"></i>Get Queue Number
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<footer class="footer mt-5 py-3 bg-dark text-white-50">
    <div class="container text-center">
        <span>&copy; <?php echo date("Y"); ?> Smart Queue Management System. All rights reserved.</span>
        <p class="text-muted small">Developed for Ayuntamiento - De La Salle University - Dasmariñas</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // loader with delay
    window.addEventListener("load", function () {
      setTimeout(() => {
        document.getElementById("loader-overlay").style.opacity = "0";
        setTimeout(() => {
          document.getElementById("loader-overlay").style.display = "none";
        }, 300);
      }, 1000);
    });

    // loader on link clicks
    document.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", function (e) {
        const href = link.getAttribute("href");
        if (href && !href.startsWith("#") && !href.startsWith("javascript:")) {
          document.getElementById("loader-overlay").style.display = "flex";
          document.getElementById("loader-overlay").style.opacity = "1";
        }
      });
    });

    // Navbar scroll effect
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 50) {
            navbar.style.background = 'var(--dark-green-gradient)'; // Use CSS variable
            navbar.style.backdropFilter = 'blur(15px)';
            navbar.style.boxShadow = '0 6px 25px var(--shadow-medium)'; // Enhanced shadow
        } else {
            navbar.style.background = 'var(--dark-green-gradient)'; // Use CSS variable
            navbar.style.backdropFilter = 'blur(10px)';
            navbar.style.boxShadow = '0 4px 20px var(--shadow-light)';
        }
    });

    // Bootstrap form validation
    (function () {
        'use strict'
        var forms = document.querySelectorAll('.needs-validation')
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
                    form.classList.add('was-validated')
                }, false)
            })
    })()
</script>

</body>
</html>