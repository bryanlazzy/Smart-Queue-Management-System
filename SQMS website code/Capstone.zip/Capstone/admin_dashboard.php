<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

$admin = $_SESSION['admin'];
$table = $admin['service_table'];

// Handle AJAX requests for auto-refresh
if (isset($_GET['ajax']) && $_GET['ajax'] == 'refresh') {
    header('Content-Type: application/json');
    
    // Get current queue
    $current = $conn->query("SELECT * FROM `$table` ORDER BY queuenumber ASC LIMIT 1")->fetch_assoc();
    
    // Get full queue
    $queue = $conn->query("SELECT * FROM `$table` ORDER BY queuenumber ASC");
    $queueData = [];
    while ($row = $queue->fetch_assoc()) {
        $queueData[] = $row;
    }
    
    // Get total count
    $totalCount = $conn->query("SELECT COUNT(*) as total FROM `$table`")->fetch_assoc()['total'];
    
    echo json_encode([
        'current' => $current,
        'queue' => $queueData,
        'total' => $totalCount
    ]);
    exit();
}

// "Next" button
if (isset($_POST['next'])) {
    $conn->query("DELETE FROM `$table` ORDER BY queuenumber ASC LIMIT 1");
    // Redirect to prevent form resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// "Reset" button
if (isset($_POST['reset'])) {
    $conn->query("TRUNCATE TABLE `$table`");
    // Redirect to prevent form resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Initial data load
$current = $conn->query("SELECT * FROM `$table` ORDER BY queuenumber ASC LIMIT 1")->fetch_assoc();
$queue = $conn->query("SELECT * FROM `$table` ORDER BY queuenumber ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Smart Queue</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="styles/admindashboard.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #00743F;
            --light-green: #67C589;
            --accent-green: #B8E6C4;
            --bg-light: #F8FAF9;
            --text-dark: #2C3E50;
            --shadow-light: rgba(0, 116, 63, 0.1);
            --shadow-medium: rgba(0, 116, 63, 0.2);
            --dark-green-gradient: linear-gradient(135deg, var(--primary-green) 0%, #005a32 100%);
        }
    </style>
</head>
<body class="bg-light">
    
<div class="refresh-indicator" id="refreshIndicator">
    <i class="fas fa-sync-alt fa-spin me-2"></i>Updating...
</div>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand fs-5 fw-bold text-wrap" href="index.php">
            <i class="fas fa-project-diagram me-2"></i>Smart Queue Management System
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navItems"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navItems">
            <ul class="navbar-nav ms-auto">
               <li class="nav-item">
                    <a class="nav-link logout-link" href="logout.php"> <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5 pt-5">
    <div class="card shadow-lg border-0 mb-4">
        <div class="card-header text-white text-center py-3">
            <h2 class="mb-0"><i class="fas fa-tachometer-alt me-2"></i>Admin Dashboard</h2>
            <p class="lead mb-0">Manage your queue efficiently.</p>
        </div>
        <div class="card-body p-4">
            <h3 class="card-title mb-3">Welcome, <strong><?php echo htmlspecialchars($admin['username']); ?></strong></h3>
            <h5 class="mb-4">Monitoring Queue for: <strong class="text-primary-green"><?php echo htmlspecialchars($table); ?></strong></h5>

            <!-- Auto-refresh controls -->
            <div class="auto-refresh-controls">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h6 class="mb-2">
                            <span class="status-indicator status-active" id="statusIndicator"></span>
                            Auto-refresh: <span id="refreshStatus">Active</span>
                        </h6>
                        <small class="text-muted">Updates every <span id="intervalDisplay">3</span> seconds</small>
                    </div>
                    <div class="col-md-6 text-end">
                        <button class="btn btn-sm btn-outline-success me-2" id="toggleRefresh">
                            <i class="fas fa-pause" id="toggleIcon"></i> Pause
                        </button>
                        <button class="btn btn-sm btn-outline-primary" id="manualRefresh">
                            <i class="fas fa-sync-alt"></i> Refresh Now
                        </button>
                    </div>
                </div>
            </div>

            <div class="mt-4 mb-4 p-3 bg-light border rounded shadow-sm current-queue-box" id="currentQueueBox">
                <?php if ($current): ?>
                    <h4 class="text-primary-green mb-2"><i class="fas fa-user-friends me-2"></i>Current Queue: <span class="display-6 fw-bold">#<?php echo $current['queuenumber']; ?></span></h4>
                    <p class="mb-1"><strong>Name:</strong> <?php echo htmlspecialchars($current['name']); ?><br>
                    <strong>Contact:</strong> <?php echo htmlspecialchars($current['contactnumber']); ?></p>
                <?php else: ?>
                    <h4 class="text-secondary"><i class="fas fa-info-circle me-2"></i>No users currently in queue.</h4>
                <?php endif; ?>
            </div>

            <form method="POST" class="mb-4 d-flex justify-content-start flex-wrap gap-2">
                <button name="next" class="btn btn-success btn-lg action-button" type="submit">
                    <i class="fas fa-forward me-2"></i>Next
                </button>
                <button name="reset" class="btn btn-danger btn-lg action-button" type="submit" onclick="return confirm('Are you sure you want to reset the entire queue? This action cannot be undone.');">
                    <i class="fas fa-redo-alt me-2"></i>Reset Queue
                </button>
                <a href="queue_display.php" target="_blank" class="btn btn-info btn-lg action-button"> <i class="fas fa-tv me-2"></i>View Live Queue Display
                </a>
            </form>

            <h5 class="mb-3 text-primary-green">Full Queue List <span id="totalCount" class="badge bg-secondary ms-2"></span></h5>
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>Queue #</th>
                            <th>Name</th>
                            <th>Contact Number</th>
                        </tr>
                    </thead>
                    <tbody id="queueTableBody">
                        <?php if ($queue->num_rows > 0): ?>
                            <?php while ($row = $queue->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?php echo $row['queuenumber']; ?></td>
                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['contactnumber']); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="3" class="text-center">No entries in queue.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <a href="logout.php" class="btn btn-secondary btn-lg mt-3 d-flex align-items-center justify-content-center mx-auto logout-link" style="max-width: 200px;"> <i class="fas fa-sign-out-alt me-2"></i>Logout
            </a>
        </div>
    </div>
</div>

<footer class="footer mt-5 py-3 bg-dark text-white-50">
    <div class="container text-center">
        <span>&copy; <?php echo date("Y"); ?> Smart Queue Management System. All rights reserved.</span>
        <p class="small">Developed for Ayuntamiento - De La Salle University - Dasmariñas</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Auto-refresh functionality
let refreshInterval;
let isRefreshing = true;
let refreshIntervalTime = 3000; // 3 seconds

// Elements
const refreshIndicator = document.getElementById('refreshIndicator');
const currentQueueBox = document.getElementById('currentQueueBox');
const queueTableBody = document.getElementById('queueTableBody');
const totalCount = document.getElementById('totalCount');
const toggleRefreshBtn = document.getElementById('toggleRefresh');
const manualRefreshBtn = document.getElementById('manualRefresh');
const refreshStatus = document.getElementById('refreshStatus');
const statusIndicator = document.getElementById('statusIndicator');
const toggleIcon = document.getElementById('toggleIcon');
const intervalDisplay = document.getElementById('intervalDisplay');

// Initialize auto-refresh
function startAutoRefresh() {
    if (refreshInterval) clearInterval(refreshInterval);
    
    refreshInterval = setInterval(refreshQueue, refreshIntervalTime);
    isRefreshing = true;
    updateRefreshStatus();
}

function stopAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
    isRefreshing = false;
    updateRefreshStatus();
}

function updateRefreshStatus() {
    if (isRefreshing) {
        refreshStatus.textContent = 'Active';
        statusIndicator.className = 'status-indicator status-active';
        toggleIcon.className = 'fas fa-pause';
        toggleRefreshBtn.innerHTML = '<i class="fas fa-pause" id="toggleIcon"></i> Pause';
    } else {
        refreshStatus.textContent = 'Paused';
        statusIndicator.className = 'status-indicator status-paused';
        toggleIcon.className = 'fas fa-play';
        toggleRefreshBtn.innerHTML = '<i class="fas fa-play" id="toggleIcon"></i> Resume';
    }
}

function showRefreshIndicator() {
    refreshIndicator.classList.add('show');
    setTimeout(() => {
        refreshIndicator.classList.remove('show');
    }, 1000);
}

function refreshQueue() {
    showRefreshIndicator();
    
    fetch(window.location.href + '?ajax=refresh')
        .then(response => response.json())
        .then(data => {
            updateCurrentQueue(data.current);
            updateQueueTable(data.queue);
            updateTotalCount(data.total);
        })
        .catch(error => {
            console.error('Error refreshing queue:', error);
        });
}

function updateCurrentQueue(current) {
    if (current) {
        currentQueueBox.innerHTML = `
            <h4 class="text-primary-green mb-2">
                <i class="fas fa-user-friends me-2"></i>Current Queue: 
                <span class="display-6 fw-bold">#${current.queuenumber}</span>
            </h4>
            <p class="mb-1">
                <strong>Name:</strong> ${escapeHtml(current.name)}<br>
                <strong>Contact:</strong> ${escapeHtml(current.contactnumber)}
            </p>
        `;
    } else {
        currentQueueBox.innerHTML = `
            <h4 class="text-secondary">
                <i class="fas fa-info-circle me-2"></i>No users currently in queue.
            </h4>
        `;
    }
    
    // Add pulse animation
    currentQueueBox.classList.add('pulse-animation');
    setTimeout(() => {
        currentQueueBox.classList.remove('pulse-animation');
    }, 1000);
}

function updateQueueTable(queue) {
    if (queue.length > 0) {
        let tableHTML = '';
        queue.forEach(row => {
            tableHTML += `
                <tr>
                    <td>#${row.queuenumber}</td>
                    <td>${escapeHtml(row.name)}</td>
                    <td>${escapeHtml(row.contactnumber)}</td>
                </tr>
            `;
        });
        queueTableBody.innerHTML = tableHTML;
    } else {
        queueTableBody.innerHTML = '<tr><td colspan="3" class="text-center">No entries in queue.</td></tr>';
    }
}

function updateTotalCount(count) {
    totalCount.textContent = count > 0 ? count : '';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Event listeners
toggleRefreshBtn.addEventListener('click', () => {
    if (isRefreshing) {
        stopAutoRefresh();
    } else {
        startAutoRefresh();
    }
});

manualRefreshBtn.addEventListener('click', () => {
    refreshQueue();
});

// Navbar scroll effect
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.background = 'var(--dark-green-gradient)';
        navbar.style.backdropFilter = 'blur(15px)';
        navbar.style.boxShadow = '0 6px 25px var(--shadow-medium)';
    } else {
        navbar.style.background = 'var(--dark-green-gradient)';
        navbar.style.backdropFilter = 'blur(10px)';
        navbar.style.boxShadow = '0 4px 20px var(--shadow-light)';
    }
});

// Pause auto-refresh when page is not visible
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        stopAutoRefresh();
    } else {
        if (isRefreshing) {
            startAutoRefresh();
        }
    }
});

// Start auto-refresh when page loads
document.addEventListener('DOMContentLoaded', function() {
    startAutoRefresh();
    // Initial count update
    const initialRows = queueTableBody.querySelectorAll('tr');
    const initialCount = initialRows.length > 0 && !initialRows[0].querySelector('td[colspan]') ? initialRows.length : 0;
    updateTotalCount(initialCount);
});

// Handle form submissions to pause refresh temporarily
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function() {
        stopAutoRefresh();
    });
});
</script>
</body>
</html>