<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Queue Confirmation</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/submitstyle.css">
     <style>
        :root {
            --primary-green: #00743F;
            --light-green: #67C589;
            --accent-green: #B8E6C4;
            --bg-light: #F8FAF9;
            --text-dark: #2C3E50;
            --shadow-light: rgba(0, 116, 63, 0.1);
            --shadow-medium: rgba(0, 116, 63, 0.2);
        }
    </style>
</head>
<body>

<!-- Fullscreen Loading Screen -->
<div id="loader-overlay">
  <div class="loader-spinner"></div>
  <div class="loader-text">Processing your request...</div>
</div>

<?php
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $contactnumber = isset($_POST['contactnumber']) ? trim($_POST['contactnumber']) : '';
    $service = isset($_POST['service']) ? trim($_POST['service']) : '';

    // Server-side validation
    if (empty($name) || empty($contactnumber) || empty($service)) {
        die("<div class='container-result error'><h3>Error</h3><p>Please fill all fields.</p><a href='registration.php'>Back to form</a></div>");
    }

    if (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        die("<div class='container-result error'><h3>Error</h3><p>Invalid name format.</p><a href='registration.php'>Back to form</a></div>");
    }

    if (!preg_match("/^[0-9]{10,15}$/", $contactnumber)) {
        die("<div class='container-result error'><h3>Error</h3><p>Invalid mobile number format.</p><a href='registration.php'>Back to form</a></div>");
    }

    // Map services to corresponding table names
    $service_table_map = [
        "Assessment & Finance Window" => "assessment_window",
        "Posting and Unholding of Account" => "posting_unholding_account",
        "Others" => "other_service"
    ];

    if (!array_key_exists($service, $service_table_map)) {
        die("<div class='container-result error'><h3>Error</h3><p>Invalid service selected.</p><a href='registration.php'>Back to form</a></div>");
    }

    $table = $service_table_map[$service];

    // Insert data into the correct table with sms_sent = 0 (pending)
    $stmt = $conn->prepare("INSERT INTO `$table` (name, contactnumber, sms_sent, sms_sent_time) VALUES (?, ?, 0, NULL)");
    $stmt->bind_param("ss", $name, $contactnumber);

    if ($stmt->execute()) {
        $queueNumber = $stmt->insert_id;
        echo "
            <div class='container-result success'>
                <div class='success-icon'>✓</div>
                <h3>Registration Successful!</h3>
                <div class='queue-display'>
                    <div class='queue-label'>Your Queue Number</div>
                    <div class='queue-number'>#{$queueNumber}</div>
                </div>
                <div class='service-info'>
                    <p><strong>Service:</strong> $service</p>
                    <p><strong>Name:</strong> $name</p>
                    <p><strong>Contact:</strong> $contactnumber</p>
                </div>
                <div class='sms-notification'>
                    <i>📱 An SMS notification will be sent to your mobile number shortly.</i>
                </div>
                <div class='instructions'>
                    <p>Please keep your queue number and wait for your turn.</p>
                    <p>You can monitor the live queue display at the service window.</p>
                </div>
                <a href='registration.php' class='btn-back'>Register Another</a>
                <a href='index.php' class='btn-home'>Back to Home</a>
            </div>
        ";

    } else {
        echo "<div class='container-result error'><h3>Error</h3><p>Database error: " . $stmt->error . "</p><a href='registration.php'>Back to form</a></div>";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "<div class='container-result error'><h3>Error</h3><p>Invalid request method.</p><a href='registration.php'>Back to form</a></div>";
}
?>

<script>
  // Enhanced loader with delay
  window.addEventListener("load", function () {
    setTimeout(() => {
      document.getElementById("loader-overlay").style.opacity = "0";
      setTimeout(() => {
        document.getElementById("loader-overlay").style.display = "none";
      }, 300);
    }, 1000);
  });

  // Show loader on link clicks
  document.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", function (e) {
      const href = link.getAttribute("href");
      if (href && !href.startsWith("#") && !href.startsWith("javascript:")) {
        document.getElementById("loader-overlay").style.display = "flex";
        document.getElementById("loader-overlay").style.opacity = "1";
      }
    });
  });
</script>

</body>
</html>